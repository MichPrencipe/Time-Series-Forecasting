import os
import tensorflow as tf
import numpy as np
import pandas as pd

class model:
    def __init__(self, path):
        self.model_final = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel/model_final.h5'))

    def predict(self, X, categories):
        reg_predictions = np.array([])
        X_temp = X
        for reg in range(0,18,9):
            pred_temp = self.model_final.predict(np.expand_dims(X_temp, axis=2))
            if(len(reg_predictions)==0):
                reg_predictions = np.array(pred_temp)
            else:
                reg_predictions = np.concatenate((reg_predictions,pred_temp),axis=1)
            X_temp = np.concatenate((X_temp[:,9:],pred_temp), axis=1)
            
        return reg_predictions